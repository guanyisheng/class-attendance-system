-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: kaoqin
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendances`
--

DROP TABLE IF EXISTS `attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `attendance_time` time NOT NULL,
  `attendance_order` int(11) NOT NULL,
  `status` enum('正常','事假','病假','公假','迟到','缺勤') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  CONSTRAINT `attendances_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendances`
--

LOCK TABLES `attendances` WRITE;
/*!40000 ALTER TABLE `attendances` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presets`
--

DROP TABLE IF EXISTS `presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `presets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `student_list` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `presets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presets`
--

LOCK TABLES `presets` WRITE;
/*!40000 ALTER TABLE `presets` DISABLE KEYS */;
INSERT INTO `presets` VALUES (1,1,'计算机应用技术一班','廖思男\r\n何启现\r\n王志成\r\n蒋龙先\r\n赵浩雄\r\n曹靖\r\n李天宇\r\n杨芳菲\r\n吴昱臻\r\n张玲芬\r\n刘吉均\r\n王京龙\r\n张俊豪\r\n姚茂然\r\n张林\r\n张颜颜\r\n汪诗涵\r\n李耀辉\r\n张劲涛\r\n昂鑫\r\n周永凤\r\n李健学\r\n杨涵\r\n朱煜坤\r\n杨鑫旺\r\n邹爽\r\n张仁\r\n管乙聲\r\n李扬\r\n李兴杰\r\n刘芯如\r\n张标\r\n黄凤有\r\n和瑞宝\r\n余光映\r\n邓莉\r\n李杰\r\n李玉蓉\r\n解英杰\r\n张天秀\r\n杨宏\r\n李乾铭\r\n潘浩\r\n龚大玺\r\n熊志祥\r\n张丁翊\r\n白新然\r\n曹云蕊\r\n侯轶梁\r\n岩香\r\n岩罕旺\r\n刘子鹏\r\n杨喆宇\r\n彭赛邦\r\n马腾飞\r\n邓代超\r\n周杨竣\r\n杨帆');
/*!40000 ALTER TABLE `presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=699 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (641,'廖思男'),(642,'何启现'),(643,'王志成'),(644,'蒋龙先'),(645,'赵浩雄'),(646,'曹靖'),(647,'李天宇'),(648,'杨芳菲'),(649,'吴昱臻'),(650,'张玲芬'),(651,'刘吉均'),(652,'王京龙'),(653,'张俊豪'),(654,'姚茂然'),(655,'张林'),(656,'张颜颜'),(657,'汪诗涵'),(658,'李耀辉'),(659,'张劲涛'),(660,'昂鑫'),(661,'周永凤'),(662,'李健学'),(663,'杨涵'),(664,'朱煜坤'),(665,'杨鑫旺'),(666,'邹爽'),(667,'张仁'),(668,'管乙聲'),(669,'李扬'),(670,'李兴杰'),(671,'刘芯如'),(672,'张标'),(673,'黄凤有'),(674,'和瑞宝'),(675,'余光映'),(676,'邓莉'),(677,'李杰'),(678,'李玉蓉'),(679,'解英杰'),(680,'张天秀'),(681,'杨宏'),(682,'李乾铭'),(683,'潘浩'),(684,'龚大玺'),(685,'熊志祥'),(686,'张丁翊'),(687,'白新然'),(688,'曹云蕊'),(689,'侯轶梁'),(690,'岩香'),(691,'岩罕旺'),(692,'刘子鹏'),(693,'杨喆宇'),(694,'彭赛邦'),(695,'马腾飞'),(696,'邓代超'),(697,'周杨竣'),(698,'杨帆');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'gys','Gys019951'),(2,'admin','admin123');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'kaoqin'
--

--
-- Dumping routines for database 'kaoqin'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-28 14:05:31
